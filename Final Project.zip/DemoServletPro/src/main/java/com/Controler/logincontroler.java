package com.Controler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.logindb;

import CombeeanClass.LoginBeean;

/**
 * Servlet implementation class logincontroler
 */
@WebServlet("/logincontroler")
public class logincontroler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public logincontroler() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String username=request.getParameter("txt_username");
	String password=request.getParameter("txt_password");
	
	LoginBeean lb=new LoginBeean();
    lb.setUsername(username);
    lb.setPassword(password);
    
    logindb ld=new logindb();
    String msg = ld.authorizelogin(lb);
    
    if(msg.equals("Successfully Login")) {
    	request.getRequestDispatcher("profile.html").forward(request, response);
    
    }
    else {
    	request.getRequestDispatcher("login.html").include(request, response);
    }
	
	}

}
