package com.Controler;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.db.logindb;
import com.db.regdb;

import CombeeanClass.LoginBeean;
import CombeeanClass.RegisterBeean;

/**
 * Servlet implementation class regcontroller
 */
@WebServlet("/regcontroller")
public class regcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public regcontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname = request.getParameter("txt_firstname");
        String lastname  = request.getParameter("txt_lastname");
        String username  = request.getParameter("txt_username");
        String password  = request.getParameter("txt_password");

        
        RegisterBeean rb = new RegisterBeean();
        rb.setFirstname(firstname);   
        rb.setLastname(lastname);
        rb.setUsername(username);
        rb.setPassword(password);
		
		regdb rd = new regdb();
		String msg =rd.authorizeRegister(rb);
		
		
	    if(msg.equals("Successfully Register")) {
	    	request.getRequestDispatcher("login.html").forward(request, response);
	    
	    }
	    else {
	    	request.getRequestDispatcher("reg.html").include(request, response);
	    }
	}

}
