package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CombeeanClass.LoginBeean;

public class logindb {
   public String authorizelogin(LoginBeean ld) {
		String username=ld.getUsername();
		String password=ld.getPassword();
		
		String dbusername="";
		String dbpassword="";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/web","root","srinithi007");
            PreparedStatement  stm1=conn.prepareStatement ("SELECT * FROM webdetail WHERE username=? AND password=?");
            stm1.setString(1, username);
            stm1.setString(2, password); 
            
            ResultSet rs=stm1.executeQuery();
            
            while(rs.next()) {
            	dbusername = rs.getString("username");
            	dbpassword = rs.getString("password");
            	
            	if(username.equals(dbusername) && password.equals(dbpassword)) {
            		return "Successfully Login";
            	}
            	
            }
		       
            
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        return "WORNG USERNAMEAND PASSWORD";
		
	}

}
