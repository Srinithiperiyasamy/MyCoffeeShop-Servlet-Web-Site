package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CombeeanClass.RegisterBeean;

public class regdb {

	public String authorizeRegister(RegisterBeean rd) {
		String firstname=rd.getFirstname();
		String lastname=rd.getLastname();
		String username=rd.getUsername();
		String password=rd.getPassword();
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/web","root","srinithi007");
			PreparedStatement stm1 = conn.prepareStatement(
				    "INSERT INTO webdetail(firstname, lastname, username, password) VALUES (?, ?, ?, ?)"
				);

				stm1.setString(1, firstname);
				stm1.setString(2, lastname);
				stm1.setString(3, username);
				stm1.setString(4, password);
                stm1.executeUpdate();
                
                return "Successfully Register";
            
            
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "FAILED REGISTER";
        
		
		
		
	}

	
	}

	
	


