package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/sqlpra")
public class sqlpra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public sqlpra() {
        super();
          }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/Html");
	    String username = request.getParameter("un");
	    String email = request.getParameter("em");
	    String password = request.getParameter("pw");
	    String city = request.getParameter("ct");
	    
	    try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userinputs","root","srinithi007");
	            
			 PreparedStatement  stm1=conn.prepareStatement ("insert into detail (username,password,email,city)values(?,?,?,?)");
		       
		       stm1.setString(1,username);
		       stm1.setString(2,password);
		       stm1.setString(3,email);
		       stm1.setString(4,city);
		       
		       stm1.executeUpdate();
		       System.out.println("Username from form: " + username);
		       System.out.println("Email from form: " + email);
		       System.out.println("Password from form: " + password);
		       System.out.println("City from form: " + city);

		       System.out.println("  value created successfully!");	
				
			
			
			
			
			
			
		} catch (ClassNotFoundException e) {
				e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		
			}
	

}
