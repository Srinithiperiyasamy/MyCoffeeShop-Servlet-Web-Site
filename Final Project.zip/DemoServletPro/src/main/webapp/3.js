const btn = document.getElementById('menuBtn');
const drawer = document.getElementById('drawer');
const overlay = document.getElementById('overlay');

function openDrawer(){
  drawer.classList.add('open');
  overlay.classList.add('show');
  btn.setAttribute('aria-expanded','true');
  // focus the first link for accessibility
  const firstLink = drawer.querySelector('.menu a');
  firstLink && firstLink.focus();
}
function closeDrawer(){
  drawer.classList.remove('open');
  overlay.classList.remove('show');
  btn.setAttribute('aria-expanded','false');
  btn.focus();
}

btn.addEventListener('click', () => {
  const isOpen = drawer.classList.contains('open');
  isOpen ? closeDrawer() : openDrawer();
});
overlay.addEventListener('click', closeDrawer);

// Close on ESC
window.addEventListener('keydown', (e) => {
  if(e.key === 'Escape' && drawer.classList.contains('open')) closeDrawer();
});

// Optional: close when a link is clicked
drawer.addEventListener('click', (e) => {
  if(e.target.tagName === 'A') closeDrawer();
});
