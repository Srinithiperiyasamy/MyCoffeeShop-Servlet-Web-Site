// orderForm.addEventListener("submit", function(e) {
//   e.preventDefault();

//   const orderDetails = {
//     id: product.id,
//     name: product.name,
//     price: product.price,
//     img: product.img,
//     desc: product.desc,
//     customerName: orderForm.name.value,
//     address: orderForm.address.value,
//     phone: orderForm.phone.value,
//     date: new Date().toLocaleString()
//   };

//   // Save to localStorage
//   let orders = JSON.parse(localStorage.getItem("orders")) || [];
//   orders.push(orderDetails);
//   localStorage.setItem("orders", JSON.stringify(orders));

//   alert(`✅ Order placed for ${product.name}!`);

//   // Redirect to My Orders page
//   window.location.href = "orders.html";
// });

// confirm.js

// ✅ Load product info from query string
const params = new URLSearchParams(window.location.search);
const itemId = params.get("item");
const product = products.find(p => p.id === itemId);

const container = document.getElementById("confirmContainer");

if (product) {
  container.innerHTML = `
    <img src="${product.img}" alt="${product.name}">
    <h2>${product.name}</h2>
    <p class="price">₹${product.price}</p>
    <p>${product.desc}</p>

    <form class="order-form" id="orderForm">
      <label>Name:</label>
      <input type="text" id="custName" required>
      
      <label>Address:</label>
      <textarea id="custAddr" rows="3" required></textarea>
      
      <label>Phone:</label>
      <input type="tel" id="custPhone" required>
      
      <button type="submit" class="submit-btn">Place Order</button>
    </form>
  `;
} else {
  container.innerHTML = `<p>Product not found.</p>`;
}

// ✅ Notification function
function addNotification(msg) {
  let notifs = JSON.parse(localStorage.getItem("notifications")) || [];
  notifs.unshift({
    message: msg,
    time: new Date().toLocaleString()
  });
  localStorage.setItem("notifications", JSON.stringify(notifs));
}

// ✅ Handle order form submit
document.addEventListener("submit", function(e) {
  if (e.target.id === "orderForm") {
    e.preventDefault();

    const name = document.getElementById("custName").value;
    const addr = document.getElementById("custAddr").value;
    const phone = document.getElementById("custPhone").value;

    // Save order to localStorage (like before)
    let orders = JSON.parse(localStorage.getItem("orders")) || [];
    orders.push({
      productId: product.id,
      name,
      addr,
      phone,
      orderedAt: new Date().toLocaleString()
    });
    localStorage.setItem("orders", JSON.stringify(orders));

    // ✅ Add notification here
    addNotification(`Order placed: ${product.name} by ${name}`);

    alert("Order placed successfully!");
    window.location.href = "orders.html"; // go to My Orders page
  }
});

