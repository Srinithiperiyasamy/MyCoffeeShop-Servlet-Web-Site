document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll(".wishlist-btn");
  const popup = document.getElementById("popup");

  // Load saved wishlist (array of product objects)
  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

  // Apply saved state to buttons
  buttons.forEach(btn => {
    const productCard = btn.closest(".product-card");
    const name = productCard.querySelector("h2").textContent.trim();

    // Check if already saved
    if (wishlist.some(item => item.name === name)) {
      btn.classList.add("active");
    }

    btn.addEventListener("click", () => {
      const product = {
        name: productCard.querySelector("h2").textContent.trim(),
        price: productCard.querySelector(".price").textContent.trim(),
        img: productCard.querySelector("img").getAttribute("src")
      };

      const index = wishlist.findIndex(item => item.name === product.name);

      if (index > -1) {
        // Remove from wishlist
        wishlist.splice(index, 1);
        btn.classList.remove("active");
        showPopup("❌ Removed from Wishlist");
      } else {
        // Add to wishlist
        wishlist.push(product);
        btn.classList.add("active");
        showPopup("❤️ Added to Wishlist");
      }

      // Save to localStorage
      localStorage.setItem("wishlist", JSON.stringify(wishlist));
    });
  });

  function showPopup(message) {
    popup.textContent = message;
    popup.classList.add("show");
    setTimeout(() => {
      popup.classList.remove("show");
    }, 1500);
  }
});

