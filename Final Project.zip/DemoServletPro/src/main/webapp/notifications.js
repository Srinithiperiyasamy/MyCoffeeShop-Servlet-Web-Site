function addNotification(msg) {
  let notifs = JSON.parse(localStorage.getItem("notifications")) || [];
  notifs.unshift({
    message: msg,
    time: new Date().toLocaleString()
  });
  localStorage.setItem("notifications", JSON.stringify(notifs));
}

function showNotifications() {
  const container = document.getElementById("notifications");
  let notifs = JSON.parse(localStorage.getItem("notifications")) || [];

  if (notifs.length === 0) {
    container.innerHTML = `<p>No new notifications.</p>`;
    return;
  }

  container.innerHTML = notifs.map(n => `
    <div class="notif-box">
      <p>${n.message}</p>
      <p class="notif-time">${n.time}</p>
    </div>
  `).join("");
}

function clearNotifications() {
  localStorage.removeItem("notifications");
  showNotifications();
}
