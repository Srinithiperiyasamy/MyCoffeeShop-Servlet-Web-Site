
const products = [
  // ☕ Hot & Classic Brews
  {
    id: "1",
    name: "Espresso",
    price: "₹120",
    desc: "Rich, bold, and full-bodied. A shot of pure energy.",
    img: "espresso.jpg",
    category: "brews"
  },
  {
    id: "2",
    name: "Cappuccino",
    price: "₹150",
    desc: "Smooth espresso topped with frothy milk foam.",
    img: "cappuccino.jpg",
    category: "brews"
  },
  {
    id: "3",
    name: "Latte",
    price: "₹180",
    desc: "Creamy milk and espresso in perfect harmony.",
    img: "latte.jpg",
    category: "brews"
  },
  {
    id: "4",
    name: "Cold Brew",
    price: "₹200",
    desc: "Slow-brewed for hours. Smooth, refreshing & bold.",
    img: "coldbrew.jpg",
    category: "brews"
  },
  {
    id: "5",
    name: "Cold Frappe",
    price: "₹250",
    desc: "Icy, creamy, and topped with whipped delight.",
    img: "Cold Frappe.jpg",
    category: "brews"
  },
  {
    id: "6",
    name: "Frappe",
    price: "₹300",
    desc: "Chilled coffee blended to creamy perfection.",
    img: "Frappe.jpg",
    category: "brews"
  },
  {
    id: "7",
    name: "Turkish Coffee",
    price: "₹260",
    desc: "Strong, unfiltered, and deeply aromatic tradition.",
    img: "Turkish Coffee.jpg",
    category: "brews"
  },
  {
    id: "8",
    name: "Iced Coffee",
    price: "₹200",
    desc: "Chilled classic with milk & sugar — summer favorite!",
    img: "Iced Coffee.webp",
    category: "brews"
  },
  {
    id: "9",
    name: "Macchiato",
    price: "₹160",
    desc: "Espresso “stained” with a dollop of steamed milk.",
    img: "macchiato.webp",
    category: "brews"
  },

  // 🍔 Snacks
  {
    id: "10",
    name: "Veg Cutlet",
    price: "₹110",
    desc: "Crispy cutlets packed with veggies & spices.",
    img: "cutlet.jpg",
    category: "snacks"
  },
  {
    id: "11",
    name: "Cookies",
    price: "₹50",
    desc: "Crunchy on the outside, soft inside, loaded with rich chocolate chips.",
    img: "Cookies.jpg",
    category: "snacks"
  },
  {
    id: "12",
    name: "Coffee Walnut",
    price: "₹530",
    desc: "Bold coffee flavor balanced with crunchy walnuts.",
    img: "coffee-cake.jpg",
    category: "snacks"
  },
  {
    id: "13",
    name: "Grilled Sandwich",
    price: "₹80",
    desc: "Golden toasted bread filled with fresh veggies and melted cheese.",
    img: "sandwich.jpg",
    category: "snacks"
  },
  {
    id: "14",
    name: "Nutella Shake",
    price: "₹310",
    desc: "Rich Nutella blended with ice cream & milk.",
    img: "nutella-shake.webp",
    category: "snacks"
  },
  {
    id: "15",
    name: "Chicken Nuggets",
    price: "₹150",
    desc: "Crispy nuggets with juicy chicken filling.",
    img: "chicken-nuggets.jpg",
    category: "snacks"
  },
  {
    id: "16",
    name: "Chikoo Shake",
    price: "₹220",
    desc: "Sweet chikoo fruit blended into a creamy shake.",
    img: "chikoo-shake.jpg",
    category: "snacks"
  },
  {
    id: "17",
    name: "Black Forest",
    price: "₹480",
    desc: "Layers of chocolate sponge, cherries & whipped cream.",
    img: "blackforest.jpg",
    category: "snacks"
  },
  {
    id: "18",
    name: "Samosa",
    price: "₹50",
    desc: "Crispy golden pastry filled with spicy potatoes.",
    img: "samosa.jpg",
    category: "snacks"
  },
  {
    id: "samosa",
    name: "Samosa",
    price: 50,
    desc: "Crispy golden pastry filled with spicy potatoes.",
    img: "samosa.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "cookies",
    name: "Cookies",
    price: 50,
    desc: "Crunchy on the outside, soft inside, loaded with rich chocolate chips.",
    img: "Cookies.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "spring-rolls",
    name: "Spring Rolls",
    price: 90,
    desc: "Crispy rolls packed with fresh veggies.",
    img: "spring-rolls.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "french-fries",
    name: "French Fries",
    price: 100,
    desc: "Golden, crunchy fries served with dip.",
    img: "French Fries.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "cheese-balls",
    name: "Cheese Balls",
    price: 120,
    desc: "Crispy outside, gooey cheesy inside.",
    img: "cheese-balls.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "garlic-bread",
    name: "Garlic Bread",
    price: 130,
    desc: "Buttery bread topped with garlic & herbs.",
    img: "garlic-bread.webp",
    category: "Snacks & Bites",
  },
  {
    id: "chicken-nuggets",
    name: "Chicken Nuggets",
    price: 150,
    desc: "Crispy nuggets with juicy chicken filling.",
    img: "chicken-nuggets.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "pakora",
    name: "Pakora",
    price: 70,
    desc: "Spiced fritters fried till golden.",
    img: "pakora.jpg",
    category: "Snacks & Bites",
  },

  // Second Section (Snacks/Shakes)
  {
    id: "corn-chat",
    name: "Corn Chat",
    price: 90,
    desc: "Tangy, spicy and buttery corn snack.",
    img: "corn-chat.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "nachos",
    name: "Nachos",
    price: 160,
    desc: "Crispy nachos served with cheesy dip.",
    img: "nachos.webp",
    category: "Snacks & Bites",
  },
  {
    id: "sandwich",
    name: "Grilled Sandwich",
    price: 80,
    desc: "Golden toasted bread filled with fresh veggies and melted cheese.",
    img: "sandwich.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "pasta-snack",
    name: "Pasta Snack",
    price: 180,
    desc: "Cheesy pasta served as a quick snack.",
    img: "pasta-snack.avif",
    category: "Snacks & Bites",
  },
  {
    id: "veg-puff",
    name: "Veg Puff",
    price: 60,
    desc: "Flaky puff stuffed with spiced veggies.",
    img: "veg-puff.webp",
    category: "Snacks & Bites",
  },
  {
    id: "mini-burger",
    name: "Mini Burger",
    price: 140,
    desc: "Small but mighty burger with cheesy bite.",
    img: "burger.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "paneer-tikka",
    name: "Paneer Tikka",
    price: 200,
    desc: "Grilled paneer cubes with smoky spices.",
    img: "paneer-tikka.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "veg-cutlet",
    name: "Veg Cutlet",
    price: 110,
    desc: "Crispy cutlets packed with veggies & spices.",
    img: "cutlet.jpg",
    category: "Snacks & Bites",
  },
  {
    id: "chocolate-shake",
    name: "Chocolate Shake",
    price: 220,
    img: "chocolate-shake.jpg",
    desc: "Classic creamy shake made with rich cocoa & milk.",
    category: "shake"
  },
  {
    id: "vanilla-shake",
    name: "Vanilla Shake",
    price: 200,
    img: "vanilla-shake.jpg",
    desc: "Smooth vanilla delight with whipped cream topping.",
    category: "shake"
  },
  {
    id: "strawberry-shake",
    name: "Strawberry Shake",
    price: 230,
    img: "strawberry-shake.jpg",
    desc: "Refreshing berry blend with a creamy finish.",
    category: "shake"
  },
  {
    id: "mango-shake",
    name: "Mango Shake",
    price: 240,
    img: "mango-shake.jpg",
    desc: "Sweet tropical mango shake with chilled cream.",
    category: "shake"
  },
  {
    id: "oreo-shake",
    name: "Oreo Shake",
    price: 250,
    img: "oreo-shake.jpg",
    desc: "Crunchy Oreo cookies blended into creamy goodness.",
    category: "shake"
  },
  {
    id: "butterscotch-shake",
    name: "Butterscotch Shake",
    price: 260,
    img: "butterscotch-shake.jpg",
    desc: "Caramel crunch with smooth butterscotch cream.",
    category: "shake"
  },
  {
    id: "banana-shake",
    name: "Banana Shake",
    price: 210,
    img: "banana-shake.jpg",
    desc: "Naturally sweet shake with banana and chilled milk.",
    category: "shake"
  },
  {
    id: "coffee-shake",
    name: "Coffee Shake",
    price: 270,
    img: "coffee-shake.jpeg",
    desc: "Strong coffee blended into creamy icy perfection.",
    category: "shake"
  },
  {
    id: "kitkat-shake",
    name: "KitKat Shake",
    price: 280,
    img: "kitkat-shake.jpg",
    desc: "Crunchy KitKat bars blended with rich milk & cream.",
    category: "shake"
  },
  {
    id: "chikoo-shake",
    name: "Chikoo Shake",
    price: 220,
    img: "chikoo-shake.jpg",
    desc: "Sweet chikoo fruit blended into a creamy shake.",
    category: "shake"
  },
  {
    id: "dryfruit-shake",
    name: "Dry Fruit Shake",
    price: 300,
    img: "dryfruit-shake.jpg",
    desc: "Loaded with nuts & dry fruits for a royal taste.",
    category: "shake"
  },
  {
    id: "blueberry-shake",
    name: "Blueberry Shake",
    price: 290,
    img: "blueberry-shake.jpg",
    desc: "Refreshing blueberry flavor with creamy texture.",
    category: "shake"
  },
  {
    id: "nutella-shake",
    name: "Nutella Shake",
    price: 310,
    img: "nutella-shake.webp",
    desc: "Rich Nutella blended with ice cream & milk.",
    category: "shake"
  },
  {
    id: "pistachio-shake",
    name: "Pistachio Shake",
    price: 320,
    img: "pistachio-shake.jpg",
    desc: "Creamy pistachio blend topped with nutty crunch.",
    category: "shake"
  },
  {
    id: "espresso",
    name: "Espresso",
    price: 120,
    img: "espresso.jpg",
    desc: "Rich, bold, and full-bodied. A shot of pure energy."
  },
  {
    id: "americano",
    name: "Americano",
    price: 300,
    img: "americano.jpg",
    desc: "Espresso mellowed with hot water for a smooth sip."
  },
  {
    id: "cappuccino",
    name: "Cappuccino",
    price: 150,
    img: "hot Cappuccino.jpg",
    desc: "Silky foam, balanced with espresso and steamed milk."
  },
  {
    id: "latte",
    name: "Latte",
    price: 180,
    img: "latte.jpg",
    desc: "Creamy milk and espresso in perfect harmony."
  },
  {
    id: "macchiato",
    name: "Macchiato",
    price: 160,
    img: "macchiato.webp",
    desc: "Espresso “stained” with a dollop of steamed milk."
  },
  {
    id: "flatwhite",
    name: "Flat White",
    price: 250,
    img: "Flat White.jpg",
    desc: "Espresso with steamed milk and a thin layer of microfoam."
  },
  {
    id: "doppio",
    name: "Doppio",
    price: 300,
    img: "Doppio.jpg",
    desc: "A strong, bold double shot of espresso, rich with crema and pure energy."
  },
  {
    id: "blockcoffee",
    name: "Block Coffee",
    price: 160,
    img: "Block Coffee.jpg",
    desc: "Brewed coffee with no additions (also known as regular coffee)."
  },
  {
    id: "cortado",
    name: "Cortado",
    price: 200,
    img: "Cortado.jpg",
    desc: "Espresso cut with a small amount of warm milk."
  },
  {
    id: "cafeaulait",
    name: "Cafe au lait",
    price: 160,
    img: "coffee-bg.jpg",
    desc: "Smoothly balanced with equal parts rich coffee and creamy steamed milk."
  },
  {
    id: "chocolate-truffle",
    name: "Chocolate Truffle",
    price: 500,
    img: "chocolate-cake.webp",
    desc: "Rich, moist chocolate cake with silky ganache layers."
  },
  {
    id: "red-velvet",
    name: "Red Velvet",
    price: 600,
    img: "redvelvet.webp",
    desc: "Soft red sponge layered with cream cheese frosting."
  },
  {
    id: "cheesecake",
    name: "New York Cheesecake",
    price: 550,
    img: "cheesecake.jpg",
    desc: "Classic creamy cheesecake with a buttery biscuit base."
  },
  {
    id: "black-forest",
    name: "Black Forest",
    price: 480,
    img: "blackforest.jpg",
    desc: "Layers of chocolate sponge, cherries & whipped cream."
  },
  {
    id: "fruit-cake",
    name: "Fruit Cake",
    price: 450,
    img: "fruitcake.jpg",
    desc: "Soft sponge topped with fresh seasonal fruits & cream."
  },
  {
    id: "butterscotch-delight",
    name: "Butterscotch Delight",
    price: 520,
    img: "butterscotch.jpg",
    desc: "Crunchy caramel bits with smooth butterscotch cream."
  },
  {
    id: "strawberry-bliss",
    name: "Strawberry Bliss",
    price: 480,
    img: "strawberry.jpg",
    desc: "Light sponge layered with strawberry cream & toppings."
  },
  {
    id: "pineapple-cream",
    name: "Pineapple Cream",
    price: 470,
    img: "pineapple.jpg",
    desc: "Fluffy vanilla sponge with pineapple chunks & cream."
  },
  {
    id: "coffee-walnut",
    name: "Coffee Walnut",
    price: 530,
    img: "coffee-cake.jpg",
    desc: "Bold coffee flavor balanced with crunchy walnuts."
  },
  {
    id: "oreo-crunch",
    name: "Oreo Crunch",
    price: 550,
    img: "oreo.jpg",
    desc: "Chocolate cake loaded with Oreo chunks & cream."
  },
  {
    id: "coldbrew",
    name: "Cold Brew",
    price: 200,
    desc: "Slow-brewed for hours. Smooth, refreshing & bold.",
    img: "coldbrew.jpg"
  },
  {
    id: "cappuccino2",
    name: "Cappuccino",
    price: 150,
    desc: "Smooth espresso topped with frothy milk foam.",
    img: "cappuccino.jpg"
  },
  {
    id: "coldfrappe",
    name: "Cold Frappe",
    price: 250,
    desc: "Icy, creamy, and topped with whipped delight.",
    img: "Cold Frappe.jpg"
  },
  {
    id: "frappe",
    name: "Frappe",
    price: 300,
    desc: "Chilled coffee blended to creamy perfection.",
    img: "Frappe.jpg"
  },
  {
    id: "icedcoffee",
    name: "Iced Coffee",
    price: 200,
    desc: "Chilled classic with milk & sugar — summer favorite!",
    img: "Iced Coffee.webp"
  },
  {
    id: "icedlatte",
    name: "Iced Latte",
    price: 220,
    desc: "Smooth espresso poured over chilled milk and ice.",
    img: "IcedLatte.jpg"
  },
  {
    id: "icedamericano",
    name: "Iced Americano",
    price: 180,
    desc: "Bold espresso diluted with cold water and ice — crisp & light.",
    img: "IcedAmericano.jpg"
  },
  {
    id: "caramelicedcoffee",
    name: "Caramel Iced Coffee",
    price: 250,
    desc: "Chilled coffee sweetened with caramel syrup & creamy milk.",
    img: "CaramelIcedCoffee.jpg"
  },
  {
    id: "icedmacchiato",
    name: "Iced Macchiato",
    price: 270,
    desc: "Layers of chilled milk, ice, and rich espresso for a bold kick.",
    img: "IcedMacchiato.jpg"
  },
  {
    id: "affogato",
    name: "Affogato",
    price: 300,
    desc: "A scoop of creamy vanilla ice cream drowned in hot espresso.",
    img: "Affogato.jpg"
  }
];


