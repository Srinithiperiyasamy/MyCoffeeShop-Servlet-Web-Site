
  // ✅ Define addNotification here (or load from notifications.js)
  function addNotification(msg) {
    let notifs = JSON.parse(localStorage.getItem("notifications")) || [];
    notifs.unshift({
      message: msg,
      time: new Date().toLocaleString()
    });
    localStorage.setItem("notifications", JSON.stringify(notifs));
  }

  window.onload = function () {
    const params = new URLSearchParams(window.location.search);
    const itemId = params.get("item");

    const product = products.find(p => p.id === itemId);

    if (product) {
      document.getElementById("order").innerHTML = `
        <div class="product-profile">
          <img src="${product.img}" alt="${product.name}">
          <h2>${product.name}</h2>
          <p class="price">${product.price}</p>
          <p>${product.desc}</p>
          <button class="order-btn" id="confirmBtn">Confirm Order</button>
        </div>
      `;

      // ✅ Corrected click handler
      document.getElementById("confirmBtn").addEventListener("click", () => {
        addNotification(`Started checkout for: ${product.name}`);
        window.location.href = 'confirm.html?item=' + product.id;
      });
    } else {
      document.getElementById("order").innerHTML = "<h2>Product not found</h2>";
    }
  };

