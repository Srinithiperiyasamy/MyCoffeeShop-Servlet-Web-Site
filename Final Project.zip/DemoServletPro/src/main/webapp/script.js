// Show About section on click
document.getElementById("about-link").addEventListener("click", function() {
  const aboutSection = document.getElementById("about");
  
  // toggle show/hide
  if (aboutSection.style.display === "none" || aboutSection.style.display === "") {
    aboutSection.style.display = "block";
    aboutSection.scrollIntoView({ behavior: "smooth" });
  } else {
    aboutSection.style.display = "none";
  }
});
