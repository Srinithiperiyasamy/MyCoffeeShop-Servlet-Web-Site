document.addEventListener("DOMContentLoaded", function () {
  const container = document.getElementById("snackContainer");
  const leftBtn = document.getElementById("snackLeft");
  const rightBtn = document.getElementById("snackRight");

  leftBtn.addEventListener("click", () => {
    container.scrollBy({ left: -300, behavior: "smooth" });
  });

  rightBtn.addEventListener("click", () => {
    container.scrollBy({ left: 300, behavior: "smooth" });
  });
});
