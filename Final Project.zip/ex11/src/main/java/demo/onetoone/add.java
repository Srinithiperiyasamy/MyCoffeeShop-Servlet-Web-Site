package demo.onetoone;

import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.Transaction;

import org.hibernate.cfg.Configuration;



public class add {

    public static void main(String[] args) {

        Configuration config = new Configuration();

        config.configure("hibernate.cfg.xml");



        SessionFactory sessionFactory = config.buildSessionFactory();



        Session session = sessionFactory.openSession();



        

        Transaction txn = session.beginTransaction();



       

        movie m = new movie();

        song s = new song();



        m.setMovie_name("VTV");

        m.setActor("str");

        m.setActress("Thrisha");

        

        session.persist(m);

        s.setSong_name("Mannipaaya");

        s.setSinger("shreya ghoshal");

        s.setMusicDirector("A.R.Rahman");

        s.setMn(m);

        session.persist(s);

        





       

        txn.commit();

        session.close();

        sessionFactory.close();



        System.out.println("Data inserted successfully!");

    }

}