package demo.onetoone;

import jakarta.persistence.*;

@Entity
@Table(name = "Movies")
public class movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "movie_name")
    private String movie_name;

    @Column(name = "actor")
    private String actor;

    @Column(name = "actress")
    private String actress;

    
    @OneToOne(mappedBy = "mn", cascade = CascadeType.ALL)
    private song song;

    // Getters and setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getMovie_name() {
        return movie_name;
    }
    public void setMovie_name(String movie_name) {
        this.movie_name = movie_name;
    }

    public String getActor() {
        return actor;
    }
    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getActress() {
        return actress;
    }
    public void setActress(String actress) {
        this.actress = actress;
    }

    public song getSong() {
        return song;
    }
    public void setSong(song song) {
        this.song = song;
    }
}
