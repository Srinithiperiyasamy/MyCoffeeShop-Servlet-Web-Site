package demo.onetoone;

import jakarta.persistence.*;

@Entity
@Table(name = "Songs")
public class song {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;  // primary key

    @Column(name = "song_name")
    private String song_name;

    @Column(name = "singer")
    private String singer;

    @Column(name = "musicDirector")
    private String musicDirector;

    @OneToOne
    @JoinColumn(name = "movie_id") // foreign key referencing movie table
    private movie mn;

    // Getters & setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getSong_name() { return song_name; }
    public void setSong_name(String song_name) { this.song_name = song_name; }

    public String getSinger() { return singer; }
    public void setSinger(String singer) { this.singer = singer; }

    public String getMusicDirector() { return musicDirector; }
    public void setMusicDirector(String musicDirector) { this.musicDirector = musicDirector; }

    public movie getMn() { return mn; }
    public void setMn(movie mn) { this.mn = mn; }
}
