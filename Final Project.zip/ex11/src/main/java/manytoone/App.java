package manytoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		Configuration config = new Configuration();
		config.configure("hibernate3.cfg.xml");
        SessionFactory sessionFactory = config.buildSessionFactory();
        Session session = sessionFactory.openSession();
        
        Employee e1=new Employee();
        e1.setEmpname("Virat");
        e1.setEmail("virat@gamil.com");
        
        Employee e2=new Employee();
        e2.setEmpname("Bhuvi");
        e2.setEmail("bhuvi@gamil.com");
        
        
        Address add1=new Address();
        add1.setCity("Noida");
        add1.setState("UP");
        add1.setCountry("India");
        add1.setPincode("600 010");
        
        e1.setAddress(add1);
        e2.setAddress(add1);
        
        
        Employee e3=new Employee();
        e3.setEmpname("Shreyas");
        e3.setEmail("shreyas@gamil.com");
        
        Employee e4=new Employee();
        e4.setEmpname("Rahul");
        e4.setEmail("rahul@gamil.com");
        
        
        Address add2=new Address();
        add2.setCity("Annanager");
        add2.setState("Madurai");
        add2.setCountry("Tamil Nadu");
        add2.setPincode("600 310");
        
        e3.setAddress(add2);
        e4.setAddress(add2);
        
        session.persist(e1);
        session.persist(e2);
        session.persist(e3);
        session.persist(e4);
        
        Transaction tx = session.beginTransaction();
        tx.commit();
        session.close();
        sessionFactory.close();



        System.out.println("Data inserted successfully!");
        
        
        
        
        
        
        
	}

}
