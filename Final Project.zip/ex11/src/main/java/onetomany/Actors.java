package onetomany;

import jakarta.persistence.*;

@Entity
@Table(name="actors")
public class Actors {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="actor_name")
    private String actors_name;

    @Column(name="age")
    private String age;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getActors_name() {
        return actors_name;
    }
    public void setActors_name(String actors_name) {
        this.actors_name = actors_name;
    }

    public String getAge() {
        return age;
    }
    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return actors_name + " (" + age + ")";
    }
}
