package onetomany;




import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import java.util.*;

public class Details {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate2.cfg.xml");
        Session session = cfg.buildSessionFactory().openSession();

        Actors a1 = new Actors();
        a1.setActors_name("vijay");
        a1.setAge("50");

        Actors a2 = new Actors();
        a2.setActors_name("ajith");
        a2.setAge("51");

        Actors a3 = new Actors();
        a3.setActors_name("surya");
        a3.setAge("48");

        Actors a4 = new Actors();
        a4.setActors_name("vikram");
        a4.setAge("52");

        ArrayList<Actors> list = new ArrayList<Actors>();
        list.add(a1);
        list.add(a2);

        ArrayList<Actors> listtwo = new ArrayList<Actors>();
        listtwo.add(a3);
        listtwo.add(a4);

        Movie m1 = new Movie();
        m1.setMoviename("Beast");
        m1.setActors(list);

        Movie m2 = new Movie();
        m2.setMoviename("Kaithi");
        m2.setActors(listtwo);

        session.beginTransaction();
        session.save(m1);
        session.save(m2);
        session.getTransaction().commit();

        session.close();
    }
}
