package com.springBootCrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.springBootCrud.model.Books;
import com.springBootCrud.service.BooksService;

@RestController
@RequestMapping("/books")
public class BooksController {

    @Autowired
    private BooksService booksService;

    @GetMapping("/")
    public String home() {
        return "Welcome to Books API!";
    }

    @GetMapping("/test")
    public String test() {
        return "It works!";
    }

    @GetMapping
    public List<Books> getAllBooks() {
        return booksService.getAllBooks();
    }

    @GetMapping("/{bookid}")
    public Books getBookById(@PathVariable("bookid") int bookid) {
        return booksService.getBooksById(bookid);
    }

    @DeleteMapping("/{bookid}")
    public void delete(@PathVariable("bookid") int bookid) {
        booksService.delete(bookid);
    }

    @PostMapping
    public Books saveBook(@RequestBody Books books) {
        booksService.saveOrUpdate(books);
        return books;
    }

    @PutMapping
    public Books update(@RequestBody Books books) {
        booksService.saveOrUpdate(books);
        return books;
    }
}
