package com.springBootCrud.repository;
import org.springframework.data.repository.CrudRepository;
import com.springBootCrud.model.Books;

	public interface BooksRepository extends CrudRepository<Books, Integer> {
	}



